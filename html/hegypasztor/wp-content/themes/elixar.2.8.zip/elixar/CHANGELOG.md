###Version 2.8 [24/09/2019]
* Breadcrumbs issue(Attachment Image) fixed.
###Version 2.7 [19/09/2019]
* translation issue fixed in comments.php.
* Remove whitespace and minor bug fixed.
###Version 2.6 [16/09/2019]
* Tested with latest WordPress.
* image license added.
* Minor bug fixed.
###Version 2.5 [23/08/2019]
* Demo importer issue fixed. Now added manually. Go to Dashboard Admin Panel >> Appearance >> Elixar Theme >> Elixar Demo Importer Files.
* Minor bug fixed.
###Version 2.4 [03/08/2019]
* Fixed issue of full image on post & page.
* Update demo importer files.
* Other improvements.
###Version 2.3 [16/07/2019]
* Home section title issue fixed.
* Callout button styling (Secondary button) issue fixed.
* Other minor bug fixed.
###Version 2.2 [08/05/2019]
* Hero section transparent button issue fixed.
* Other minor bug fixed.
###Version 2.1 [16/04/2019]
* Only recommend plugins used that are essential for theme to work.
* User can remove footer link, without editing php files. just Go to General Settings >> Footer Copyright Options >> Copyright Content Here.
###Version 2.0
* When Theme Unit Test, Drop down menu issue fixed.
* Related post issue fixed.
* Other minor bug fixed.
###Version 1.9
* All required issue fixed.
###Version 1.8
* Minor bug fixed.
###Version 1.7
* Theme Sniffer required issue fixed.
###Version 1.6
* All required issue fixed.
###Version 1.5
* All required issue fixed.
###Version 1.4
* All required issue fixed like translation, email address etc.
###Version 1.3
* All required issue fixed.
###Version 1.2
* Fixed some required issue.
###Version 1.1
* Copyright issue fixed.
* Invalid URI fixed.
* Minor bug fixed.
###Version 1.0
* First public release.

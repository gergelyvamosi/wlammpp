<?php

//
// http://www.nextweb.hu/wp-content/plugins/otp_simplepay-woocommerce-payment-gateway/ipn.php
//

// new ipn method implemented in otp_simplepay-woocommerce-payment-gateway.php v.0.0.2, this file is obsolete
//
// IPN URL példa: http://robot-italod.hu/?wc-api=otp_simplepay_gateway - a site-név cserélendő !!

 	/**
	 * Optional error riporting
	 */	 
	error_reporting(E_ALL);
	ini_set('display_errors', '1');
		
	/**
	 * Import config data
	 */		
	require_once 'sdk/config.php';

	/**
	 * Import SimplePayment class
	 */
	require_once 'sdk/SimplePayment.class.php';
	
	/**
	 * Set merchant account data by currency
	 */		
	 
	$orderCurrency = (isset($_REQUEST['CURRENCY'])) ? $_REQUEST['CURRENCY'] : 'N/A';
	 
	/**
	 * Start IPN
	 */
	$ipn = new SimpleIpn($otpsp_config, $orderCurrency);
   	
	/**
	 * IPN successful
	 * This is the real end of successful payment
	 */		
	if($ipn->validateReceived()){	
    	/**
		 * End of payment: SUCCESSFUL
         * echo <EPAYMENT> (must have)
		 */
		$ipn->confirmReceived();
		               		 
		/**
		 * Your code here
		 */
         /*
		 print "<pre>";	 
         print_r($_REQUEST);         
		 print "</pre>";
        */
    
//
// Get cURL resource
$curl = curl_init();
//
// 941991809315591671917073 IPN 2019-05-30 00:00:23 SALEDATE=2019-05-29 21:59:51
// 941991809315591671917073 IPN 2019-05-30 00:00:23 REFNO=99615758
// 941991809315591671917073 IPN 2019-05-30 00:00:23 REFNOEXT=941991809315591671917073
//
// 941991809315591671917073 IPN 2019-05-30 00:00:23 IPN_PNAME=816
// 941991809315591671917073 IPN 2019-05-30 00:00:23 IPN_PCODE=wc_order_tFAY5cZpbxz4p
//
// 941991809315592591422560 IPN 2019-05-31 01:32:43 IPN_DATE=20190531013243
//
$curl_opt = array (
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => 'http://www.nextweb.hu/penztar/order-received/' . $ipn->postData['IPN_PNAME'][0] . '/?key=' . $ipn->postData['IPN_PCODE'][0] . '&order_ref=' . $ipn->postData['REFNOEXT'] . '&date=' . urlencode(''.$ipn->postData['SALEDATE']) . '&payrefno=' . $ipn->postData['REFNO'] . '&ipn_date=' . $ipn->postData['IPN_DATE'] . '&ipn_request=1',
    CURLOPT_USERAGENT => 'Insider cURL Request'
    );
//
// Set some options - we are passing in a useragent too here
curl_setopt_array($curl, $curl_opt);
// Send the request & save response to $resp
$resp = curl_exec($curl);
// Close request to clear up some resources
curl_close($curl);

//If $contents is not a boolean FALSE value.
// Create an empty array
$okArray=array();
// Push elements to the array
array_push($okArray, "IPN_REQUEST", "OK");
// Create an empty array
$errArray=array();
// Push elements to the array
array_push($errArray, "IPN_REQUEST", "ERROR");
if($resp) {
    $ipn->logFunc("IPN", $curl_opt, $ipn->postData['REFNOEXT']);
    $ipn->logFunc("IPN", $okArray, $ipn->postData['REFNOEXT']);
} else {
    $ipn->logFunc("IPN", $errArray, $ipn->postData['REFNOEXT']);
}
//
    
	}

		
    /**
     * Error and debug info
     */  
	$ipn->errorLogger(); 	
	
	/*
    if ($ipn->debug) {
		foreach ($ipn->debugMessage as $debug) {
			print $debug . "\n";
		}
    }
    if (count($ipn->errorMessage) > 0) {
		foreach ($ipn->debugMessage as $debug) {
			print $debug . "\n";
		}
		foreach ($ipn->errorMessage as $error) {
			print $error . "\n";
		}		
    }
	*/
    
?>



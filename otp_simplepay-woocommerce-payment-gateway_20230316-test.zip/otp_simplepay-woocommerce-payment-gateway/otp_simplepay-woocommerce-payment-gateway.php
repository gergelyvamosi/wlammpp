<?php
/*
	Plugin Name: OTP SimplePay WooCommerce Payment Gateway
	Plugin URI: http://otp_simplepay-woocommerce-payment-gateway
	Description: OTP Simplepay WooCommerce Payment Gateway allows you to accept local and International payment via MasterCard & Visa Card.
	Version: 0.0.2
	Author: Gergely Vámosi
	Author URI: http://nextweb.hu/
	License:           GPL-2.0+
 	License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 	GitHub Plugin URI: https://github.com/profgvamosi/otp_simplepay-woocommerce-payment-gateway
*/

if ( ! defined( 'ABSPATH' ) )
	exit;

//
//Import config data    
//require_once 'sdk/config.php';

//Import SimplePayment class
//require_once 'sdk/SimplePayment.class.php';
//

add_action( 'plugins_loaded', 'otp_wc_simplepay_init', 0 );

function otp_wc_simplepay_init() {

	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

	/**
 	 * Gateway class
 	 */
	class WC_Otp_SimplePay_Gateway extends WC_Payment_Gateway {

		public function __construct() {

			$this->id 					= 'otp_simplepay_gateway';
    		$this->icon 				= apply_filters( 'woocommerce_simplepay_icon', plugins_url( 'assets/images/bankcards_simplepay_2022.png' , __FILE__ ) );
			$this->has_fields 			= false;
			$this->order_button_text    = 'Fizetés';
			$this->notify_url        	= WC()->api_request_url( 'WC_Otp_SimplePay_Gateway' );
        	$this->method_title     	= 'OTP SimplePay';
        	$this->method_description  	= '<a href="http://simplepartner.hu/PaymentService/Fizetesi_tajekoztato.pdf" target="_blank"><img border="0" width="548" height="40" src="' . plugins_url( 'assets/images/bankcards_simplepay_2022.png' , __FILE__ ) . '" title=" SimplePay - Online bankkártyás fizetés" alt=" SimplePay vásárlói tájékoztató"></a><br /><br />Elfogadott bankkártyák: MasterCard, Maestro, Visa';

			$this->init_form_fields();
			$this->init_settings();

			// Define user set variables
			$this->title 				= $this->get_option( 'title' );
			$this->description 			= $this->get_option( 'description' );
			$this->testmode			= $this->get_option( 'testmode' ) === 'yes' ? true : false;

			$this->huf_merchant		= $this->get_option( 'huf_merchant' );

			$this->huf_secret_key		= $this->get_option( 'huf_secret_key' );

			//Actions
			add_action( 'woocommerce_receipt_otp_simplepay_gateway', array( $this, 'receipt_page' ) );
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
			add_action( 'woocommerce_payment_complete',  array( $this, 'payment_complete_page' ) );

			// new ipn solution
			add_action( 'woocommerce_api_' . $this->id, array( $this, 'handle_ipn' ) );

//
/*
add_action( 'woocommerce_order_status_pending', 'nextwebhu_pending', 10, 1);
add_action( 'woocommerce_order_status_failed', 'nextwebhu_failed', 10, 1);
add_action( 'woocommerce_order_status_on-hold', 'nextwebhu_hold', 10, 1);
// Note that it's woocommerce_order_status_on-hold, and NOT on_hold.
add_action( 'woocommerce_order_status_processing', 'nextwebhu_processing', 10, 1);
add_action( 'woocommerce_order_status_completed', 'nextwebhu_completed', 10, 1);
add_action( 'woocommerce_order_status_refunded', 'nextwebhu_refunded', 10, 1);
add_action( 'woocommerce_order_status_cancelled', 'nextwebhu_cancelled', 10, 1);
*/

add_action( 'woocommerce_thankyou_otp_simplepay_gateway', array( $this, 'thankyou_page' ) );
//

			// Check if the gateway can be used
			if ( ! $this->is_valid_for_use() ) {
				$this->enabled = false;
			}

		}


		/**
	 	* Check if the store curreny is set to HUF
	 	**/
		public function is_valid_for_use() {

			if( ! in_array( get_woocommerce_currency(), array( 'HUF' ) ) ) {
				$this->msg = 'OTP SimplePay doesn\'t support your store currency, set it to HUF <a href="' . get_bloginfo('wpurl') . '/wp-admin/admin.php?page=wc-settings&tab=general">here</a>';
				return false;
			}

			return true;

		}


		/**
		 * Check if this gateway is enabled
		 */
		public function is_available() {

			if ( $this->enabled == "yes" ) {

				if ( ! ( $this->huf_merchant && $this->huf_secret_key ) ) {
					return false;
				}

				return true;

			}

			return false;

		}


        /**
         * Admin Panel Options
         **/
        public function admin_options() {

            echo '<h3>OTP SimplePay</h3>';
            echo '<p>OTP Simplepay WooCommerce Payment Gateway segítségével bankkártyás fizetést kezdeményezhetnek ügyfeleid a WooCommerce webshop-ban.</p>';

			if ( $this->is_valid_for_use() ) {

	            echo '<table class="form-table">';
	            $this->generate_settings_html();
	            echo '</table>';

            } else {	 ?>

				<div class="inline error"><p><strong>OTP SimplePay Payment Gateway Disabled</strong>: <?php echo $this->msg ?></p></div>

			<?php }

        }


	    /**
	     * Initialise Gateway Settings Form Fields
	    **/
		function init_form_fields() {

			$this->form_fields = array(
				'enabled' => array(
					'title' 		=> 'Engedélyez/Tilt',
					'type' 			=> 'checkbox',
					'label' 		=> 'OTP SimplePay fizetési átjáró engedélyezése',
					'description' 	=> 'Az átjáró engedélyezése vagy tiltása.',
            		'desc_tip'      => true,
					'default' 		=> 'yes'
				),
				'title' => array(
					'title' 		=> 'Title',
					'type' 			=> 'text',
					'description' 	=> 'This controls the title which the user sees during checkout.',
        			'desc_tip'      => false,
					'default' 		=> 'Bankkártyás fizetés (OTP SimplePay)'
				),
				'description' => array(
					'title' 		=> 'Description',
					'type' 			=> 'textarea',
					'description' 	=> 'This controls the description which the user sees during checkout.',
					'default' 		=> $this->method_description
				),
				'huf_merchant' => array(
					'title'       => 'HUF Kereskedői azonosító (MERCHANT)',
					'type'        => 'text',
					'description' => 'Adja meg az OTP oldalról a kereskedői azonosítóját (szerződés szükséges)!',
					'default'     => ''
				),
				'huf_secret_key' => array(
					'title'       => 'HUF Titkosító kulcs (SECRET_KEY)',
					'type'        => 'text',
					'description' => 'Adja meg az OTP oldaláról a titkosító kulcsát (szerződés szükséges)!',
					'default'     => ''
				),
				'testing' => array(
					'title'       	=> 'Gateway tesztelés',
					'type'        	=> 'title',
					'description' 	=> 'IPN URL példa: http://robot-italod.hu/?wc-api=otp_simplepay_gateway - a site-név cserélendő !!',
				),
				'testmode' => array(
					'title'       		=> 'Teszt mód',
					'type'        		=> 'checkbox',
					'label'       		=> 'Teszt mód engedélyezése',
					'default'     		=> 'yes',
					'description' 		=> 'Test mode enables you to test payments before going live. <br />If you ready to start receiving payment on your site, kindly uncheck this.',
				)
			);

		}




	    /**
	     * Process the payment and return the result
	    **/
		public function process_payment( $order_id ) {

			$order 			= wc_get_order( $order_id );

			//http://www.nextweb.hu/penztar/order-received/709/?key=wc_order_zxAPIs0QfJpPS
			return array(
	        	'result' 	=> 'success',
				'redirect'	=> $order->get_checkout_payment_url( true )
	        );

		}


//
public function payment_complete_page( $order_id ) {
	//echo 'PAYMENT COMPLETE<br />';
}

/*
function nextwebhu_pending($order_id) {
    echo '$order_id set to PENDING';
}
function nextwebhu_failed($order_id) {
    echo '$order_id set to FAILED';
}
function nextwebhu_hold($order_id) {
    echo '$order_id set to ON HOLD';
}
function nextwebhu_processing($order_id) {
    echo '$order_id set to PROCESSING';
}
function nextwebhu_completed($order_id) {
    echo '$order_id set to COMPLETED';
}
function nextwebhu_refunded($order_id) {
    echo '$order_id set to REFUNDED';
}
function nextwebhu_cancelled($order_id) {
    echo '$order_id set to CANCELLED';
}
*/

   /**
     * Handle the IPN / IRN call.
     *
     * @return void
     */
    public function handle_ipn()
    {

	//
	//Import config data    
	require_once 'sdk/config.php';

	//Import SimplePayment class
	require_once 'sdk/SimplePayment.class.php';
	$orderCurrency = 'HUF';

$otpsp_config['SANDBOX'] = $this->testmode;
$otpsp_config['HUF_MERCHANT'] = ( $this->huf_merchant ? $this->huf_merchant : $otpsp_config['HUF_MERCHANT'] );
$otpsp_config['HUF_SECRET_KEY'] = ( $this->huf_secret_key ? $this->huf_secret_key : $otpsp_config['HUF_SECRET_KEY'] );

	//
	$ipn = new SimpleIpn($otpsp_config, $orderCurrency);

	if($ipn->validateReceived()){

		$ipn->confirmReceived();

		$order = wc_get_order( $ipn->postData['IPN_PNAME'][0] );
		//$order = wc_get_order( $ipn->postData['REFNOEXT'] );

		if($order instanceof WC_Order) {
			if ( 'REFUND' == $ipn->postData['ORDERSTATUS'] ) {
				// refund happened
				// Only handle full refunds, not partial.
				$amount = wc_format_decimal( $ipn->postData['IPN_TOTALGENERAL'] * -1, wc_get_price_decimals() );
				if ( $order->get_total() === $amount && $amount > 0 ) {
					$order->add_order_note( __('REFUND.<br />SimplePay referenciaszám: ' . $ipn->postData['REFNO'] . '<br />Megrendelés azonosító: ' . $ipn->postData['REFNOEXT'] . '<br />Dátum: ' . $ipn->postData['SALEDATE'] . '<br />REFUND dátum: ' . $ipn->postData['IPN_DATE'] . '<br />REFUND total: ' . $amount, 'otp_simplepay') );				

				    	wc_create_refund([
						'amount' => $amount,
						'order_id' => $order->get_id(),
				    	]);

					/* translators: %s: payment status. */
				      	//$order->update_status( 'refunded', sprintf( __( 'Payment %s via IPN.', 'woocommerce' ), strtolower( $ipn->postData['ORDERSTATUS'] ) ) );
				}
			} else {
				// normal IPN message, fraud detection
				$order->add_order_note( __('IPN OK.<br />SimplePay referenciaszám: ' . $ipn->postData['REFNO'] . '<br />Megrendelés azonosító: ' . $ipn->postData['REFNOEXT'] . '<br />Dátum: ' . $ipn->postData['SALEDATE'] . '<br />IPN dátum: ' . $ipn->postData['IPN_DATE'], 'otp_simplepay') );
			}
		}

		// Create an empty array
		$okArray=array();
		// Push elements to the array
		array_push($okArray, "IPN_REQUEST", "OK");
		// Create an empty array
		$errArray=array();
		// Push elements to the array
		array_push($errArray, "IPN_REQUEST", "ERROR");
		if($order instanceof WC_Order) {
		    $ipn->logFunc("IPN", $okArray, $ipn->postData['REFNOEXT']);
		} else {
		    $ipn->logFunc("IPN", $errArray, $ipn->postData['REFNOEXT']);
		}
		//
				
	    	/**
	     	* Error and debug info
	    	*/  
		$ipn->errorLogger();

		header( 'HTTP/1.1 200 OK' );
    		echo "callback";
		die();

       	}
    }

public function thankyou_page( $order_id ) {

//
//Import config data    
require_once 'sdk/config.php';

//Import SimplePayment class
require_once 'sdk/SimplePayment.class.php';
$orderCurrency = 'HUF';

//

//
// http://www.nextweb.hu/penztar/order-received/832/?key=wc_order_znogu2KtJXAhu&ipn_request=1
// 941991809315591729709341 IPN 2019-05-30 01:36:29 IPN_PNAME=832
// 941991809315591729709341 IPN 2019-05-30 01:36:29 IPN_PCODE=wc_order_znogu2KtJXAhu
//
// 941991809315592591422560 IPN 2019-05-31 01:32:43 IPN_DATE=20190531013243
// ipn_date
//
if (isset($_REQUEST['ipn_request'])) {
	// ipn request from otp simplepay server
	echo 'IPN<br />';

//
$order = wc_get_order( $order_id );
//
/*    global $wpdb;

    $table_perfixed = $wpdb->prefix . 'comments';
    $results = $wpdb->get_results ("
        SELECT *
        FROM $table_perfixed
        WHERE  `comment_post_ID` = $order_id
        AND  `comment_type` LIKE  'order_note'
    ");
*/
//
// count($results) <= 1 was :)
//
//if (count($results) <= 10) {
	$order->add_order_note( __('IPN OK.<br />SimplePay referenciaszám: ' . $_REQUEST['payrefno'] . '<br />Megrendelés azonosító: ' . $_REQUEST['order_ref'] . '<br />Dátum: ' . urldecode(''.$_REQUEST['date']) . '<br />IPN dátum: ' . $_REQUEST['ipn_date'], 'otp_simplepay') );
//}
//

} else {
//


//
// options setting
//
$otpsp_config['SANDBOX'] = $this->testmode;
$otpsp_config['HUF_MERCHANT'] = ( $this->huf_merchant ? $this->huf_merchant : $otpsp_config['HUF_MERCHANT'] );
$otpsp_config['HUF_SECRET_KEY'] = ( $this->huf_secret_key ? $this->huf_secret_key : $otpsp_config['HUF_SECRET_KEY'] );
//


/**
	 * Start backref
	 */		
	$backref = new SimpleBackRef($otpsp_config, $orderCurrency );
   
	/**
	 * Add order reference number from merchant system (ORDER_REF)
	 */			
	$backref->order_ref = (isset($_REQUEST['order_ref'])) ? $_REQUEST['order_ref'] : 'N/A';
	
	$message = '';
	
	if(isset($_REQUEST['err'])){
		$backref->logFunc("BackRef", $_REQUEST, $_REQUEST['order_ref']); 
		
	/**
	 * Check backref
	 */			
	} elseif ($backref->checkResponse()){
				
		/**
		 * SUCCESSFUL card authorizing
		 * Notify user and wait for IPN
		 * Need to notify user
		 * 
		 */
		$backStatus = $backref->backStatusArray;

		// Check log if IPN message was received
		$ipnInLog = false;
		if($backref->order_ref != ""){		
			$handle = fopen($config['LOG_PATH'] . '/' . @date('Ymd') . '.log', "r");
			if ($handle) {			
				while (($line = fgets($handle)) !== false) {	 
					$logRow = explode(" ", $line);
					if (isset($logRow)) {
						if ($logRow[0] == $backref->order_ref && $logRow[1] == 'IPN') {
							if (isset($logRow[4])) {
								if (strstr($logRow[4], "COMPLETE")) {
									$ipnInLog = true;
								}							
							}
						}				
					}
				}
			}
		}
		
		// Notification by payment method		
		//CCVISAMC
		if ($backStatus['PAYMETHOD'] == 'Visa/MasterCard/Eurocard') {
			$message .= '<b><font color="green">' . SUCCESSFUL_CARD_AUTHORIZATION . '</font></b><br/>';
			if ($backStatus['ORDER_STATUS'] == 'IN_PROGRESS') {
				$message .= '<b><font color="green">' . WAITING_FOR_IPN . '</font></b><br/>';
			} elseif ($backStatus['ORDER_STATUS' ] == 'PAYMENT_AUTHORIZED') {
				$message .= '<b><font color="green">' . WAITING_FOR_IPN . '</font></b><br/>';
			} elseif ($backStatus['ORDER_STATUS'] == 'COMPLETE') {
				$completeMessage = '<b><font color="green">' . WAITING_FOR_IPN . '</font></b><br/>';
				if ($ipnInLog) {
					$completeMessage = '<b><font color="green">'. CONFIRMED_IPN .'</font></b><br/>';
				}
				$message .= $completeMessage;			
			}
		}
		//WIRE
		elseif ($backStatus['PAYMETHOD'] == 'Bank/Wire transfer') {
			$message = '<b><font color="green">' . SUCCESSFUL_WIRE . '</font></b><br/>';
			if ($backStatus['ORDER_STATUS'] == 'PAYMENT_AUTHORIZED' || $backStatus['ORDER_STATUS'] == 'COMPLETE') {
				$message .= '<b><font color="green">' . CONFIRMED_WIRE . '</font></b><br/>';
			} 			
		}
		
		/**
		 * Your code here
		 */	

// just if without errors
	$order = wc_get_order( $order_id );
	$order->payment_complete();
//

//
// http://www.nextweb.hu/penztar/order-received/838/?key=wc_order_HHfLjasUC33p7&order_ref=941991809315591801091878&order_currency=HUF&RC=000&RT=000+%7C+0&3dsecure=NO&date=2019-05-30+03%3A35%3A13&payrefno=99615781&ctrl=5ae3f1bea0e6ec33b4034dc25447d4c5
//
echo '<p><font color="green">Sikeres vásárlás (rendelés szám: <b>' . $order_id . '</b>). Köszönjük a vásárlást! E-mail értesítő elküldve.</font></p>';
echo '<p>Sikeres kártya ellenőrzés.<br />
SimplePay referenciaszám: ' . $_REQUEST['payrefno'] . '<br />
Megrendelés azonosító: ' . $backref->order_ref . '<br />
Dátum: ' . urldecode(''.$_REQUEST['date']) . '</p>';
//

	} else {
		
		/**
		 * UNSUCCESSFUL card authorizing
		 * END of transaction
		 * Need to notify user
		 * 
		 */
		$backStatus = $backref->backStatusArray;	

		$message = '<b><font color="red">' . UNSUCCESSFUL_TRANSACTION . '</font></b><br/>';
		$message .= '<b><font color="red">' . END_OF_TRANSACTION . '</font></b><br/>';
		$message .= UNSUCCESSFUL_NOTICE . '<br/><br/>';

		/**
		 * Your code here
		 */	

//
$order = wc_get_order( $order_id );
//
    global $wpdb;

    $table_perfixed = $wpdb->prefix . 'comments';
    $results = $wpdb->get_results ("
        SELECT *
        FROM $table_perfixed
        WHERE  `comment_post_ID` = $order_id
        AND  `comment_type` LIKE  'order_note'
    ");
//
if (count($results) == 0) {
	$order->add_order_note('Sikertelen tranzakció');
}
echo '<p><font color="red">Valami rosszul sikerült (rendelés szám: <b>' . $order_id . '</b>)!</font></p>';
echo '<p>Sikertelen tranzakció.<br />Kérjük, ellenőrizze a tranzakció során megadott adatok helyességét.<br />Amennyiben minden adatot helyesen adott meg, a visszautasítás okának kivizsgálása kapcsán kérjük, szíveskedjen kapcsolatba lépni kártyakibocsátó bankjával.</p>';
echo '<p>SimplePay referenciaszám: ' . $_REQUEST['payrefno'] . '<br />
Megrendelés azonosító: ' . $backref->order_ref . '<br />
Dátum: ' . urldecode(''.$_REQUEST['date']) . '</p>';
//
		 
	}
	$backref->errorLogger(); 

	/**
	 * Notification
	 */	
	if(!isset($_REQUEST['err'])){
		$message .= PAYREFNO . ': <b>' . $backStatus['PAYREFNO'] . '</b><br/>'; 
		$message .= ORDER_ID . ': <b>' . $backStatus['REFNOEXT'] . '</b><br/>';
		$message .= BACKREF_DATE . ': <b>' . $backStatus['BACKREF_DATE'] . '</b><br/>';
	} 
	
	if (isset($_REQUEST['err'])) {
		$message .= '<hr>';
		$message .= '<b><font color="red">HIBA: </font></b>  ' . $_REQUEST['err'] . '<br/>'; 
	}
//

//
}
//

}
//


		/**
	     * Output for the order received page.
	    **/
		public function receipt_page( $order_id ) {


//
// http://www.nextweb.hu/penztar/order-pay/895/?key=wc_order_Q8GDAEbNsYqqt&order_ref=941991809315595018512087&order_currency=HUF&redirect=1
//
if ( $_GET['order_ref'] != '' && $_GET['redirect'] != '' ) {
	echo '<p><font color="red"><b>Megszakított tranzakció!</b></font><br/>Ön megszakította a fizetést, vagy lejárt a tranzakció maximális ideje!</p>';
}
//
// http://www.nextweb.hu/penztar/order-pay/895/?key=wc_order_Q8GDAEbNsYqqt&order_ref=941991809315595018635686&order_currency=HUF
//
if ( $_GET['order_ref'] != ''  && $_GET['redirect'] == '' ) {
	echo '<p><font color="red"><b>Időtúllépéses tranzakció!</b></font><br/>Ön megszakította a fizetést, vagy lejárt a tranzakció maximális ideje!</p>';
}
//


			$order = wc_get_order( $order_id );

//payment_scripts();
//
//Import config data    
require_once 'sdk/config.php';

//Import SimplePayment class
require_once 'sdk/SimplePayment.class.php';
//

if ( ! is_checkout_pay_page() ) {
				return;
			}

			if ( is_checkout_pay_page() && get_query_var( 'order-pay' ) ) {

				$order_key 			= urldecode( $_GET['key'] );
				//$order_id  			= absint( get_query_var( 'order-pay' ) );

				//$order        		= wc_get_order( $order_id );
//
$billing_first_name = method_exists( $order, 'get_billing_first_name' ) ? $order->get_billing_first_name() : $order->billing_first_name;
$billing_last_name = method_exists( $order, 'get_billing_last_name' ) ? $order->get_billing_last_name() : $order->billing_last_name;
$billing_company = method_exists( $order, 'get_billing_company' ) ? $order->get_billing_company() : $order->billing_company;

$billing_email = method_exists( $order, 'get_billing_email' ) ? $order->get_billing_email() : $order->billing_email;

$billing_address_1 = method_exists( $order, 'get_billing_address_1' ) ? $order->get_billing_address_1() : $order->billing_address_1;
$billing_address_2 = method_exists( $order, 'get_billing_address_2' ) ? $order->get_billing_address_2() : $order->billing_address_2;
$billing_city = method_exists( $order, 'get_billing_city' ) ? $order->get_billing_city() : $order->billing_city;
$billing_state = method_exists( $order, 'get_billing_state' ) ? $order->get_billing_state() : $order->billing_state;
$billing_postcode = method_exists( $order, 'get_billing_postcode') ? $order->get_billing_postcode() : $order->billing_postcode;
$billing_country = method_exists( $order, 'get_billing_country' ) ? $order->get_billing_country() : $order->billing_country;
$billing_phone = method_exists( $order, 'get_billing_phone' ) ? $order->get_billing_phone() : $order->billing_phone;
//
$shipping_first_name = method_exists( $order, 'get_shipping_first_name' ) ? $order->get_shipping_first_name() : $order->shipping_first_name;
$shipping_last_name = method_exists( $order, 'get_shipping_last_name' ) ? $order->get_shipping_last_name() : $order->shipping_last_name;
$shipping_company = method_exists( $order, 'get_shipping_company' ) ? $order->get_shipping_company() : $order->shipping_company;

$shipping_address_1 = method_exists( $order, 'get_shipping_address_1' ) ? $order->get_shipping_address_1() : $order->shipping_address_1;
$shipping_address_2 = method_exists( $order, 'get_shipping_address_2' ) ? $order->get_shipping_address_2() : $order->shipping_address_2;
$shipping_city = method_exists( $order, 'get_shipping_city' ) ? $order->get_shipping_city() : $order->shipping_city;
$shipping_state = method_exists( $order, 'get_shipping_state' ) ? $order->get_shipping_state() : $order->shipping_state;
$shipping_postcode = method_exists( $order, 'get_shipping_postcode') ? $order->get_shipping_postcode() : $order->shipping_postcode;
$shipping_country = method_exists( $order, 'get_shipping_country' ) ? $order->get_shipping_country() : $order->shipping_country;
//
$billing_amount = $order->get_total();
$billing_address = $billing_address_1 . ' ' . $billing_address_2;

				$description 		= '#' . $order_id . ' számú rendelés fizetése';

	            $the_order_id 		= method_exists( $order, 'get_id' ) ? $order->get_id() : $order->id;
	            $the_order_key 		= method_exists( $order, 'get_order_key' ) ? $order->get_order_key() : $order->order_key;

			}

//
define("LANGUAGE", "HU");
//LiveUpdate
define("PAYMENT_BUTTON", "SimplePay online fizetés indítása");
//Set merchant account data by currency
    $orderCurrency = 'HUF';
	$testOrderId = str_replace(array('.', ':'), "", $_SERVER['SERVER_ADDR']) . @date("U", time()) . rand(1000, 9999);


//
// options setting
//
$otpsp_config['SANDBOX'] = $this->testmode;
$otpsp_config['HUF_MERCHANT'] = ( $this->huf_merchant ? $this->huf_merchant : $otpsp_config['HUF_MERCHANT'] );
$otpsp_config['HUF_SECRET_KEY'] = ( $this->huf_secret_key ? $this->huf_secret_key : $otpsp_config['HUF_SECRET_KEY'] );
//


    //Start LiveUpdate
    $lu = new SimpleLiveUpdate($otpsp_config, $orderCurrency);
//
//echo 'HIHI'.$otpsp_config['HUF_MERCHANT'];
//

    //Order global data (need to fill by YOUR order data)    	
    $lu->setField("ORDER_REF", $testOrderId);
	

	//Payment page language
	$ppLanguage = LANGUAGE;
	if (isset($_REQUEST['testlanguage'])) {
        $ppLanguage = $_REQUEST['testlanguage'];
    }	
	$lu->setField("LANGUAGE", $ppLanguage);						//DEFAULT: HU
	
    //optional fields
	//$lu->setField("ORDER_DATE", @date("Y-m-d H:i:s"));		//DEFAULT: current date
	//$lu->setField("ORDER_TIMEOUT", 600);						//DEFAULT: 300
	$lu->setField("ORDER_TIMEOUT", 2700);				// 12x60x60 = 12 hours in sec - updated on 2022-08-25 by me - 45 min 45x60 = 2700 - updated by me on 2023-03-16
	//$lu->setField("PAY_METHOD", 'WIRE');						//DEFAULT: CCVISAMC
	//$lu->setField("DISCOUNT", 10); 							//DEFAULT: 0

	//$lu->setField("ORDER_SHIPPING", 70);						//DEFAULT: 0

	//$lu->setField("BACK_REF", $config['BACK_REF']);			//DEFAULT: $config['BACK_REF']
	$lu->setField("BACK_REF", preg_replace("/https?:\/\//", "", $order->get_checkout_order_received_url()));
//echo 'URL'.ereg_replace("http:\/\/", "", $order->get_checkout_order_received_url()).'<br/>';
//echo 'HIHI'.ereg_replace("http:\/\/", "", str_replace("order-pay", "order-received", $order->get_checkout_payment_url( true ))).'<br/>';

	//$lu->setField("TIMEOUT_URL", $config['TIMEOUT_URL']);		//DEFAULT: $config['TIMEOUT_URL']
	$lu->setField("TIMEOUT_URL", preg_replace("/https?:\/\//", "", $order->get_checkout_payment_url( true )));

	//$lu->setField("LU_ENABLE_TOKEN", true);					//Only case of uniq contract with OTP Mobil Kft.! DO NOT USE WITHOUT IT!

 

    //Sample product with gross price

    $lu->addProduct(array(
        'name' => $order_id,						//product name [ string ]
        'code' => $the_order_key,                            		//merchant systemwide unique product ID [ string ]
//        'name' => 'Rendelés',						//product name [ string ]
//        'code' => $order_id,                            		//merchant systemwide unique product ID [ string ]
        'info' => $description,     					//product description [ string ]
        'price' => $billing_amount,                              	//product price [ HUF: integer | EUR, USD decimal 0.00 ]

        'vat' => 0,                                     		//product tax rate [ in case of gross price: 0 ] (percent)
        'qty' => 1                                      		//product quantity [ integer ] 
    ));

    //Billing data
    $lu->setField("BILL_FNAME", $billing_first_name);
    $lu->setField("BILL_LNAME", $billing_last_name);
    $lu->setField("BILL_EMAIL", $billing_email); 
    $lu->setField("BILL_PHONE", $billing_phone);
    if ($billing_company != '') $lu->setField("BILL_COMPANY", $billing_company);	//optional
    //$lu->setField("BILL_FISCALCODE", " ");                  	//optional
    $lu->setField("BILL_COUNTRYCODE", "HU");
    $lu->setField("BILL_STATE", $billing_state);
    $lu->setField("BILL_CITY", $billing_city); 
    $lu->setField("BILL_ADDRESS", $billing_address_1); 
    if ($billing_address_2 != '') $lu->setField("BILL_ADDRESS2", $billing_address_2);		//optional
    $lu->setField("BILL_ZIPCODE", $billing_postcode); 
            
    //Delivery data
    $lu->setField("DELIVERY_FNAME", $shipping_first_name != '' ? $shipping_first_name : $billing_first_name); 
    $lu->setField("DELIVERY_LNAME", $shipping_last_name != '' ? $shipping_last_name : $billing_last_name);
    if ($shipping_company != '' || $billing_company != '') $lu->setField("DELIVERY_COMPANY", $shipping_company != '' ? $shipping_company : $billing_company);				//optional
    //$lu->setField("DELIVERY_EMAIL", "");			//optional
    $lu->setField("DELIVERY_PHONE", $billing_phone);
    $lu->setField("DELIVERY_COUNTRYCODE", "HU");
    $lu->setField("DELIVERY_STATE", $shipping_state != '' ? $shipping_state : $billing_state);
    $lu->setField("DELIVERY_CITY", $shipping_city != '' ? $shipping_city : $billing_city);
    $lu->setField("DELIVERY_ADDRESS", $shipping_address_1 != '' ? $shipping_address_1 : $billing_address_1); 
    if ($shipping_address_2 != '' || $billing_address_2 != '') $lu->setField("DELIVERY_ADDRESS2", $shipping_address_2 != '' ? $shipping_address_2 : $billing_address_2);			//optional
    $lu->setField("DELIVERY_ZIPCODE", $shipping_postcode != '' ? $shipping_postcode : $billing_postcode);

/*
    //Billing data
    $lu->setField("BILL_FNAME", "Tester");
    $lu->setField("BILL_LNAME", "SimplePay");
    $lu->setField("BILL_EMAIL", "sdk_test@otpmobil.com"); 
    $lu->setField("BILL_PHONE", "36201234567");
    //$lu->setField("BILL_COMPANY", "Company name");          	//optional
    //$lu->setField("BILL_FISCALCODE", " ");                  	//optional
    $lu->setField("BILL_COUNTRYCODE", "HU");
    $lu->setField("BILL_STATE", "State");
    $lu->setField("BILL_CITY", "City"); 
    $lu->setField("BILL_ADDRESS", 'First line address'); 
    //$lu->setField("BILL_ADDRESS2", "Second line address");    //optional
    $lu->setField("BILL_ZIPCODE", "1234"); 
            
    //Delivery data
    $lu->setField("DELIVERY_FNAME", "Tester"); 
    $lu->setField("DELIVERY_LNAME", "SimplePay"); 
    //$lu->setField("DELIVERY_EMAIL", ""); 						//optional
    $lu->setField("DELIVERY_PHONE", "36201234567"); 
    $lu->setField("DELIVERY_COUNTRYCODE", "HU");
    $lu->setField("DELIVERY_STATE", "State");
    $lu->setField("DELIVERY_CITY", "City");
    $lu->setField("DELIVERY_ADDRESS", "First line address"); 
    //$lu->setField("DELIVERY_ADDRESS2", "Second line address");//optional
    $lu->setField("DELIVERY_ZIPCODE", "1234"); 
*/

	$display = $lu->createHtmlForm('SimplePayForm', 'button', PAYMENT_BUTTON);
	echo $display;
//

			echo '<a class="button cancel" href="' . esc_url( $order->get_cancel_order_url() ) . '">Rendelés megszakítása &amp; kosár visszaállítása</a></div>
			';
		}


	}


	/**
 	* Add OTP SimplePay Gateway to WC
 	**/
	function otp_wc_add_simplepay_gateway( $methods ) {

		$methods[] = 'WC_Otp_SimplePay_Gateway';
		return $methods;

	}
	add_filter('woocommerce_payment_gateways', 'otp_wc_add_simplepay_gateway' );


	/**
	* Add Settings link to the plugin entry in the plugins menu
	**/
	function otp_simplepay_plugin_action_links( $links, $file ) {

	    static $this_plugin;

	    if ( ! $this_plugin ) {

	        $this_plugin = plugin_basename( __FILE__ );

	    }

	    if ( $file == $this_plugin ) {

	        $settings_link = '<a href="' . get_bloginfo('wpurl') . '/wp-admin/admin.php?page=wc-settings&tab=checkout&section=wc_otp_simplepay_gateway">Beállítások</a>';
	        array_unshift($links, $settings_link);

	    }

	    return $links;

	}
	add_filter( 'plugin_action_links', 'otp_simplepay_plugin_action_links', 10, 2 );


	/**
 	* Display the testmode notice
 	**/
	function otp_wc_simplepay_testmode_notice() {

		$simplepay_settings = get_option( 'woocommerce_otp_simplepay_gateway_settings' );

		$testmode 			= $simplepay_settings['testmode'] === 'yes' ? true : false;

		$huf_merchant		= $simplepay_settings['huf_merchant'];

		$huf_secret_key		= $simplepay_settings['huf_secret_key'];

		if ( $testmode ) {
	    ?>
		    <div class="update-nag">
		        SimplePay testmode is still enabled. Click <a href="<?php echo get_bloginfo('wpurl') ?>/wp-admin/admin.php?page=wc-settings&tab=checkout&section=otp_simplepay_gateway">here</a> to disable it when you want to start accepting live payment on your site.
		    </div>
	    <?php
		}

		// Check required fields
		if ( ! ( $huf_merchant && $huf_secret_key ) ) {
			echo '<div class="error"><p>' . sprintf( 'Please enter your SimplePay API keys <a href="%s">here</a> to be able to use the SimplePay WooCommerce plugin.', admin_url( 'admin.php?page=wc-settings&tab=checkout&section=otp_simplepay_gateway' ) ) . '</p></div>';
		}

	}
	add_action( 'admin_notices', 'otp_wc_simplepay_testmode_notice' );

}
